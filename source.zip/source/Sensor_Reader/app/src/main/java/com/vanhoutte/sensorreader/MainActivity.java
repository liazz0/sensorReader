package com.vanhoutte.sensorreader;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager senSensorManager;
    private Sensor senAccelerometer;
    private LocationManager locationManager;
    boolean running;
    boolean newFile;
    private String filename;
    private FloatingActionButton fab;
    private TextView status;
    private TextView providerUsed;
    private ColorStateList oldColors;
    private Switch record;
    private Switch calibrate;
    private ProgressBar loading;
    private ProgressBar savingBar;
    private boolean GPSbit = false;
    private List<List> logData = new ArrayList<>();
    private float latest_acc_x, latest_acc_y, latest_acc_z;
    private Handler timerHandler;
    private Runnable timerRunnable;
    private LocalDateTime startTime;
    private float [] car_orientation = new float[3];
    private float [] holder_orientation = new float[3];
    //private float acc_x, acc_y, acc_z;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar((Toolbar)findViewById((R.id.toolbar)));

        running = false;
        newFile = true;
        initRecordSwitch();
        initProgressCircle();
        initSavingBar();
        initTextViewTimer();
        initStatus();
        checkCalibration();
        providerUsed = findViewById(R.id.providerTextView);
        oldColors = providerUsed.getTextColors();
        checkLocationPermission();
        senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(running) {
                    onPause();
                    saveData();
                    record.setEnabled(true);
                    calibrate.setEnabled(true);
                }
                else if(!running){
                    if ( ContextCompat.checkSelfPermission( MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION )
                            != PackageManager.PERMISSION_GRANTED ) {
                        showAlert();
                    }
                    else {
                        logData.clear();
                        running = true;
                        startAccelerometer();
                        startLocationTracking();
                        timerHandler.postDelayed(timerRunnable, 0);
                        startTime = LocalDateTime.now();
                        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        fab.setImageDrawable(getResources().getDrawable(R.drawable.ic_stop_black_24dp));
                        status.setText("Acc running, fetching location...");
                        loading.setVisibility(View.VISIBLE);
                        record.setEnabled(false);
                        calibrate.setEnabled(false);
                    }
                }
            }
        });
        Button calBttn = findViewById(R.id.calibrationButton);
        calBttn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   if(car_orientation != null && holder_orientation != null){
                       final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                       dialog.setTitle("Reset calibration").setMessage("Overwrite previous values?")
                               .setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                                   @Override
                                   public void onClick(DialogInterface paramDialogInterface, int paramInt){
                                       Intent myIntent = new Intent(MainActivity.this, CalibrationActivity.class);
                                       MainActivity.this.startActivity(myIntent);
                                   }
                               })
                               .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                   @Override
                                   public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                                       paramDialogInterface.cancel();
                                       };
                               });
                       dialog.show();
                   }
                   else{
                       Intent myIntent = new Intent(MainActivity.this, CalibrationActivity.class);
                       MainActivity.this.startActivity(myIntent);
                   }
               }
           });
        calibrate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(calibrate.isChecked()) {
                    if (car_orientation == null && holder_orientation == null){
                        calibrate.setChecked(false);
                        Intent myIntent = new Intent(MainActivity.this, CalibrationActivity.class);
                        //myIntent.putExtra("key", value); //Optional parameters
                        MainActivity.this.startActivity(myIntent);
                    }
                }
            }
        });
    }

    public void initRecordSwitch(){
        record = findViewById(R.id.recordSwitch);
        record.setChecked(true);
        record.setEnabled(true);
    }
    public void checkCalibration(){
        Intent intent = getIntent();
        car_orientation = intent.getFloatArrayExtra("car");
        holder_orientation = intent.getFloatArrayExtra("holder");
        calibrate = findViewById(R.id.calibrationSwitch);
        if (car_orientation != null && holder_orientation != null){
            //Snackbar.make(findViewById(R.id.myCoordinatorLayout), "car_or != null", Snackbar.LENGTH_LONG).show();
            calibrate.setChecked(true);
            status.setText("Calibration done.");
        }
        calibrate.setEnabled(true);
    }
    public void initTextViewTimer(){
        timerHandler = new Handler();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                updateTextViews(latest_acc_x,latest_acc_y,latest_acc_z);
                timerHandler.postDelayed(this, 500);
            }
        };
    }
    public void initSavingBar(){
        savingBar = findViewById(R.id.savingBar);
        savingBar.setVisibility(View.GONE);
    }
    public void initProgressCircle(){
        loading = findViewById(R.id.progressBar);
        loading.setVisibility(View.GONE);
    }
    public void initStatus(){
        status = (TextView) findViewById(R.id.statusText);
        status.setText("Ready to start");
    }

    public void initialiseLogData(){
//        String legend = "time,GPS_lat,GPS_lon,a_xyz_1sec-x0,a_xyz_1sec-y0,a_xyz_1sec-z0,a_xyz_1sec-x1,a_xyz_1sec-y1,a_xyz_1sec-z1,...";
//        List<String> new_list = new ArrayList<>(Arrays.asList(legend));
//        logData.add(new_list);
        logData = new ArrayList<>();
    }

    public void startAccelerometer(){
        //todo: use timer to get accurate sensor rate
//        int READINGRATE = 250000000;
//        senSensorManager.registerListener(this, senAccelerometer , READINGRATE);
        senSensorManager.registerListener(this, senAccelerometer , SensorManager.SENSOR_DELAY_GAME);
    }

    public void startLocationTracking(){
        GPSbit = false;
        if ( ContextCompat.checkSelfPermission( MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION )
                != PackageManager.PERMISSION_GRANTED ) {
            checkLocationPermission();
        }
        if(!isLocationEnabled()){
            showAlert();
        }
        else {
//            Criteria criteria = new Criteria();
//            //criteria.setPowerRequirement(Criteria.POWER_LOW);
//            criteria.setAccuracy(Criteria.ACCURACY_FINE);
//            String provider = locationManager.getBestProvider(criteria, true);
//            if (provider != null) {
//                locationManager.requestLocationUpdates(provider, 1000, 0, locationListenerGPS);
//                providerUsed.setText(provider);
//            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListenerGPS);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, locationListenerNetwork);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //doublecheck if sensor is accelerometer
        Sensor mySensor = event.sensor;
        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) { //Linear acc = = acc - acc due to gravity
            latest_acc_x = event.values[0];
            latest_acc_y = event.values[1];
            latest_acc_z = event.values[2];
            //updateTextViews(acc_x, acc_y, acc_z);
            if (record.isChecked()) {
                updateLogData(latest_acc_x, latest_acc_y, latest_acc_z);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void updateTextViews(float x_val, float y_val, float z_val){
        TextView x_val_text = (TextView) findViewById(R.id.XValTextView);
        TextView y_val_text = (TextView) findViewById(R.id.YValTextView);
        TextView z_val_text = (TextView) findViewById(R.id.ZValTextView);
        x_val_text.setText(String.valueOf(x_val));
        y_val_text.setText(String.valueOf(y_val));
        z_val_text.setText(String.valueOf(z_val));
    }

    public void updateLogData(float x_val, float y_val, float z_val){
        String ts = String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.UTC));
        if(logData.size() < 1 || !logData.get(logData.size()-1).get(0).equals(ts)){
            //Log.w("updateLogData", "ts = "+ts+", logData_structuur = "+logData.get(logData.size()-1).get(0));
            List<String> new_list = new ArrayList<>(Arrays.asList(ts,"","", //leave room for gps data;
                    String.valueOf(x_val), String.valueOf(y_val),String.valueOf(z_val)));
            logData.add(new_list);
        }
        else{
            logData.get(logData.size()-1).add(String.valueOf(x_val));
            logData.get(logData.size()-1).add(String.valueOf(y_val));
            logData.get(logData.size()-1).add(String.valueOf(z_val));
        }
        if(logData.size()>100000){ //Prevent filling up memory with values
            List<String> last_line = logData.get(logData.size()-1);
            logData.remove(logData.size()-1);
            List<List> tempLogData = new ArrayList<>(logData);
            logData.clear();
            logData.add(last_line);
            writeToFile(tempLogData, !newFile);
            tempLogData.clear();
            if(newFile){
                newFile = false;
            }
        }
    }

    public void updateLogDataGPS(double lat, double lon){
        String ts = String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.UTC));
        if(logData.size() >= 1){
            if(logData.get(logData.size()-1).get(0).equals(ts)) {
                logData.get(logData.size() - 1).set(1, String.valueOf(lat));
                logData.get(logData.size() - 1).set(2, String.valueOf(lon));
            }
            else{
                Log.w("updateLogDataGPS", "WARNING: new timestamp created by updateLogDataGPS()!");
                List<String> new_list = new ArrayList<>(Arrays.asList(ts,String.valueOf(lat),String.valueOf(lon)));
                logData.add(new_list);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch(item.getItemId()) {
//            case R.id.action_settings:
//                return true;
            case R.id.showAxes:
                this.startActivity(new Intent(this, ShowDeviceAxisActivity.class));
                return true;
            case R.id.info:
                this.startActivity(new Intent(this, ShowInfoActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public AlertDialog popupWaiting(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.app_name);
        builder.setMessage("Saving data...");
        AlertDialog alert = builder.create();
        alert.show();
        return alert;
    }
    private void saveData(){
        if (!logData.isEmpty()) {
            savingBar.setVisibility(View.VISIBLE);
            //final String prev_status = (String) status.getText();
            status.setText("Saving logfile...");
            //Log.e("logData", "logData first line: "+logData.get(1));
            writeToFile(logData, !newFile);
            logData.clear();
            newFile = true;
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    savingBar.setVisibility(View.GONE);
                    status.setText("Ready to start");
                }
            }, 1000);
        }
    }

    private void writeToFile(List<List> data, boolean append){
        DateTimeFormatter file_dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        DateTimeFormatter log_dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd' 'HH:mm:ss");
        Context context = this;
        File path = context.getExternalFilesDir(null);
        if (!append){
            String output_dt = file_dtf.format(startTime);
            filename = "logs_"+output_dt+".csv";
        }
        File file = new File(path, filename);
        try {
            //Write logData to appropriate layout in logfile.
            FileOutputStream stream = new FileOutputStream(file, append);
            for (List<String> row: data){
                if(append == true || data.indexOf(row) != 0) {
                    String dt = log_dtf.format(LocalDateTime.ofEpochSecond(Long.parseLong(row.get(0)),0, ZoneOffset.UTC));
                    stream.write((dt + ",").getBytes());
                    for (int i = 1; i < row.size(); i++) {
                        stream.write((row.get(i) + ",").getBytes());
                    }
                }
                else {
                    String legend = "time,GPS_lat,GPS_lon,a_xyz_1sec-x0,a_xyz_1sec-y0," +
                            "a_xyz_1sec-z0,a_xyz_1sec-x1,a_xyz_1sec-y1,a_xyz_1sec-z1,...";
                    stream.write(legend.getBytes());
                    String s = "\ncalibration";
                    if (car_orientation != null && holder_orientation != null && calibrate.isChecked()){
                        s += ",car,"+car_orientation[0]+","+car_orientation[1]+","+car_orientation[2];
                        s += ",holder,"+holder_orientation[0]+","+holder_orientation[1]+","+holder_orientation[2];
                        stream.write(s.getBytes());
                    }
                    else{
                        s += ",empty";
                        stream.write(s.getBytes());
                    }
                }
                stream.write("\n".getBytes());
            }
            stream.close();
            if (!running) {
                Snackbar.make(findViewById(R.id.myCoordinatorLayout), "File saved as " + filename + "!",
                        Snackbar.LENGTH_LONG).show();
            }
            //data.clear();
            //initialiseLogData();
        }
        catch (FileNotFoundException e){
            Snackbar.make(findViewById(R.id.myCoordinatorLayout), "File not found exception", Snackbar.LENGTH_LONG).show();
        }
        catch (IOException e) {
            e.printStackTrace();
            Snackbar.make(findViewById(R.id.myCoordinatorLayout), "Saving failed", Snackbar.LENGTH_LONG).show();
        }
    }

    private boolean isLocationEnabled(){
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private void showAlert(){
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location").setMessage("Your location is turned off.\nEnable location services to use this app.")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt){
                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        finishAffinity();
                    }
                });
        dialog.show();
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                new AlertDialog.Builder(this)
                        .setTitle("Give location permission")
                        .setMessage("Enable this app to access location services?")
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .setNegativeButton("quit",  new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finishAffinity();
                            }
                        })
                        .create()
                        .show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    private final LocationListener locationListenerGPS = new LocationListener() {
        public void onLocationChanged(Location location) {
            final double longitudeGPS = location.getLongitude();
            final double latitudeGPS = location.getLatitude();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    GPSbit = true; //move this higher up the chain
                    if (record.isChecked())
                        updateLogDataGPS(latitudeGPS, longitudeGPS);
                    final TextView lon_val_text = (TextView) findViewById(R.id.lonTextView);
                    final TextView lat_val_text = (TextView) findViewById(R.id.latTextView);
                    final TextView timestamp = (TextView) findViewById(R.id.timeTextView);
                    lon_val_text.setText(String.valueOf(longitudeGPS));
                    lat_val_text.setText(String.valueOf(latitudeGPS));
                    lon_val_text.setTextColor(getColor(R.color.colorPrimary));
                    lat_val_text.setTextColor(getColor(R.color.colorPrimary));
                    timestamp.setTextColor(getColor(R.color.colorPrimary));
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            lon_val_text.setTextColor(oldColors);
                            lat_val_text.setTextColor(oldColors);
                            timestamp.setTextColor(oldColors);
                        }
                    }, 800);
                    DateTimeFormatter ts_dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy' 'HH:mm:ss");
                    timestamp.setText(ts_dtf.format(LocalDateTime.now()));
                    status.setText("Running");
                    providerUsed.setText("GPS");
                }
            });
        }
        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) { }
        @Override
        public void onProviderEnabled(String s) { }
        @Override
        public void onProviderDisabled(String s) {
            Snackbar.make(findViewById(R.id.myCoordinatorLayout), "Location provider has been disabled.", Snackbar.LENGTH_SHORT).show();
            status.setText("Location has been disabled");
            onPause();
        }
    };
    private final LocationListener locationListenerNetwork = new LocationListener() {
        public void onLocationChanged(Location location) {
            if(!GPSbit){
                final double longitudeGPS = location.getLongitude();
                final double latitudeGPS = location.getLatitude();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (record.isChecked())
                            updateLogDataGPS(latitudeGPS, longitudeGPS);
                        final TextView lon_val_text = (TextView) findViewById(R.id.lonTextView);
                        final TextView lat_val_text = (TextView) findViewById(R.id.latTextView);
                        final TextView timestamp = (TextView) findViewById(R.id.timeTextView);
                        lon_val_text.setText(String.valueOf(longitudeGPS));
                        lat_val_text.setText(String.valueOf(latitudeGPS));
                        lon_val_text.setTextColor(getColor(R.color.colorPrimary));
                        lat_val_text.setTextColor(getColor(R.color.colorPrimary));
                        timestamp.setTextColor(getColor(R.color.colorPrimary));
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                lon_val_text.setTextColor(oldColors);
                                lat_val_text.setTextColor(oldColors);
                                timestamp.setTextColor(oldColors);
                            }
                        }, 800);
                        DateTimeFormatter ts_dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy' 'HH:mm:ss");
                        timestamp.setText(ts_dtf.format(LocalDateTime.now()));
                        status.setText("Running");
                        providerUsed.setText("Network");
                    }
                });
            }
            else{
                locationManager.removeUpdates(locationListenerNetwork);
            }
        }
        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) { }
        @Override
        public void onProviderEnabled(String s) { }
        @Override
        public void onProviderDisabled(String s) {
            Snackbar.make(findViewById(R.id.myCoordinatorLayout),"Location provider has been disabled.", Snackbar.LENGTH_SHORT).show();
            status.setText("Location has been disabled");
            onPause();
        }
    };

    protected void onPause() {
        super.onPause();
        senSensorManager.unregisterListener(this);
        locationManager.removeUpdates(locationListenerGPS);
        locationManager.removeUpdates(locationListenerNetwork);
        timerHandler.removeCallbacks(timerRunnable);
        running = false;
        status.setText("Paused");
        providerUsed.setText("None");
        fab.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_arrow_black_24dp));
        loading.setVisibility(View.GONE);
        record.setEnabled(true);
        calibrate.setEnabled(true);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    protected void onResume() {
        super.onResume();
    }
}
