package com.vanhoutte.sensorreader;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import static java.lang.Math.abs;
import static java.lang.Math.PI;
import static java.lang.Math.scalb;

public class CalibrationActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private final float[] accelerometerReading = new float[3];
    private final float[] magnetometerReading = new float[3];
    private final float[] rotationMatrix = new float[9];
    private final float[] orientationAngles = new float[3];
    private TextView oriData;
    private TextView info;
    private TextView titleProgress;
    private int calibrationStep;
    private int stable_index;
    private ProgressBar savingBar;
    private Handler timerHandler;
    private Runnable timerRunnable;
    private List<Float> xPitch = new ArrayList<>();
    private List<Float> yRoll = new ArrayList<>();
    private List<Float> zYaw = new ArrayList<>();
    private float [] carValues = new float[3];
    private float [] holderValues = new float[3];
    private DecimalFormat oriFormat = new DecimalFormat("#.####");
    //Intent mainIntent = new Intent(this, MainActivity.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calibration);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Calibration");
        stable_index = 0;
        initTextViews();
        initSavingBar();
        calibrationStep = 0;
        titleProgress = findViewById(R.id.infoTitleTextView);
        info = findViewById(R.id.infoTextView);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        DecimalFormat df = new DecimalFormat("#.####");
        onResume();
        Button calBttn = findViewById(R.id.calibrateButton);
        calBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCalibration();
            }
        });
        Button cancelBttn = findViewById(R.id.cancelButton);
        cancelBttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(calibrationStep != 4){
                    onPause();
                    finishAndRemoveTask();
                }
                else{
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }
            }
        });
//        initRefreshTimer();
//        timerHandler.postDelayed(timerRunnable, 0);

//        final Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                updateOrientationAngles();
//            }
//        }, 5000);
        //updateOrientationAngles();
    }

    @Override
    public void onBackPressed() {
        if(calibrationStep == 4) {
            passValuesToMain();
        }
        else{
            super.onBackPressed();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if(calibrationStep == 4){
                    passValuesToMain();
                    return true;
                }
        }
        return false;
    }


    public void initTextViews(){
        oriData = findViewById(R.id.oriDataTextView);
        oriData.setText("Ready");
    }

    public void startCalibration(){
        if(calibrationStep == 0){
            startSensors();
            info.setText("Calibrating, just a sec...");
            savingBar.setVisibility(View.VISIBLE);
            calibrationStep = 1;
            titleProgress.setText("STEP "+calibrationStep+"/4");
        }
        else if(calibrationStep == 2){
            info.setText("Calibrating, just a sec...");
            savingBar.setVisibility(View.VISIBLE);
            calibrationStep = 3;
            titleProgress.setText("STEP "+calibrationStep+"/4");
        }
        else if(calibrationStep == 4){
            passValuesToMain();
        }
    }

    public void initSavingBar(){
        savingBar = findViewById(R.id.horizontalBar);
        savingBar.setVisibility(View.GONE);
    }

    public void passValuesToMain(){
        sensorManager.unregisterListener(this);
        Intent mainIntent = new Intent(this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        mainIntent.putExtra("car", carValues);
        mainIntent.putExtra("holder", holderValues);
        this.startActivity(mainIntent);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do something here if sensor accuracy changes.
        // You must implement this callback in your code.
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        //timerHandler.removeCallbacks(timerRunnable);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//        if (calibrationStep == 1 || calibrationStep == 3){
//            startSensors();
//        }
    }

    public void startSensors(){
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
        Sensor magneticField = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magneticField != null) {
            sensorManager.registerListener(this, magneticField,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, accelerometerReading,
                    0, accelerometerReading.length);
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, magnetometerReading,
                    0, magnetometerReading.length);
        }
        updateOrientationAngles();
    }

    public void updateOrientationAngles() {
        SensorManager.getRotationMatrix(rotationMatrix, null,
                accelerometerReading, magnetometerReading);
        SensorManager.getOrientation(rotationMatrix, orientationAngles);
        if(calibrationStep == 1 || calibrationStep == 3) {
            xPitch.add(orientationAngles[0] * 180 / (float) PI);
            yRoll.add(orientationAngles[1] * 180 / (float) PI);
            zYaw.add(orientationAngles[2] * 180 / (float) PI);
            calibrationProcess();
        }
    }

    public void calibrationProcess(){
        if (xPitch.size() % 20 == 0 && xPitch.size() > 24) {
            int average_over = 24;
            if (checkStableValue(average_over)) {
                updateReferenceTextView(stable_index, average_over);
            }
//            else {
//                Snackbar.make(findViewById(R.id.crdLayout), "Device not stable.", Snackbar.LENGTH_SHORT).show();
//            }
        }
        else if(xPitch.size()%12 == 0){
            String full_text = "";
            for (float val: orientationAngles) {
                full_text += oriFormat.format(val*180/PI)+"°, ";
            }
            oriData.setText(full_text.substring(0,full_text.length()-2));
        }
    }

    public boolean checkStableValue(int numbers){
        int begin = xPitch.size()-numbers;
        int i = begin+1;
        while(i<xPitch.size() && i-begin<numbers) {
            float diffx = abs(xPitch.get(begin) - xPitch.get(i));
            float diffy = abs(yRoll.get(begin) - yRoll.get(i));
            float diffz = abs(zYaw.get(begin) - zYaw.get(i));
            if (diffx > 3 || diffy > 3 || diffz > 3) {
                return false;
            }
            i++;
        }
        stable_index = begin;
        return true;
    }
    public void updateReferenceTextView(int index, int numbers){
        float pitch_av = 0,roll_av = 0, yaw_av = 0;
        for(int i=index;i-index<numbers;i++){
            pitch_av += xPitch.get(i);
            roll_av += yRoll.get(i);
            yaw_av += zYaw.get(i);
            //Log.w("orientation", "pitch_av "+ xPitch.get(i)+" | roll_av "+ yRoll.get(i)+" | yaw_av "+ zYaw.get(i)); //for debugging
        }
        pitch_av /= numbers; roll_av /= numbers; yaw_av /= numbers;
        TextView info = findViewById(R.id.infoTextView);
        DecimalFormat df = new DecimalFormat("#.####");
        if (calibrationStep == 1){
            carValues[0] = pitch_av; carValues[1] = roll_av; carValues[2] = yaw_av;
            TextView target = findViewById(R.id.targetTextView);
            target.setText(""+df.format(pitch_av)+"°, " + df.format(roll_av) + "°, "+ df.format(yaw_av)+"°");
            info.setText("Car orientation saved.\nNow put your device in the " +
                    "smartphone holder in your car and press the "+
                    ((Button)findViewById(R.id.calibrateButton)).getText().toString()+
                    " button again.");
            xPitch.clear();
            yRoll.clear();
            zYaw.clear();
            calibrationStep = 2;
            savingBar.setVisibility(View.GONE);
            titleProgress.setText("STEP "+calibrationStep+"/4");
            ImageView instr_img = findViewById(R.id.instructionImageView);
            instr_img.setImageResource(R.drawable.calibration_step2_example_3);
        }
        else if (calibrationStep == 3){
            sensorManager.unregisterListener(this);
            holderValues[0] = pitch_av; holderValues[1] = roll_av; holderValues[2] = yaw_av;
            TextView holder = findViewById(R.id.holderTextView);
            holder.setText(""+df.format(pitch_av)+"°, " + df.format(roll_av) + "°, "+ df.format(yaw_av)+"°");
            xPitch.clear(); yRoll.clear(); zYaw.clear();
            calibrationStep = 4;
            ImageView instr_img = findViewById(R.id.instructionImageView);
            info.setText("How everyday feels:");
            //instr_img.setImageResource(R.drawable.lockdown_everyday); //memeke voor de fun
            info.setText("Holder orientation saved.\nCalibration successfully finished, press FINISH to save values.");
            instr_img.setImageResource(R.drawable.success);
            savingBar.setVisibility(View.GONE);
            titleProgress.setText("STEP "+calibrationStep+"/4");
            ((Button)findViewById(R.id.calibrateButton)).setText("FINISH");
            ((Button)findViewById(R.id.cancelButton)).setText("RESTART");
        }
    }

    public void initRefreshTimer(){
        timerHandler = new Handler();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                updateOrientationAngles();
                timerHandler.postDelayed(this, 500);
            }
        };
    }
}
